
#include "syscall.h"

int main()
{
	//int c = ReadInt();
	//PrintInt(c);
	//char c = ReadChar();
	//PrintChar(c);
	char str[100];
	ReadString(str,100);
	PrintString(str);
}
